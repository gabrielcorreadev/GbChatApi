<?php

return [
    'unauthorized' => 'Unauthorized',
    'forbidden' => 'Forbidden',
    'not_found' => 'Not Found',
    'method_not_allowed' => 'Method Not Allowed',
    'error_default' => 'Whoops, looks like something went wrong',
    'language_not_supported' => 'Language not supported',
];