<?php

return [
    'unauthorized' => 'Não autorizado',
    'forbidden' => 'Proibido',
    'not_found' => 'Não Encontrado',
    'method_not_allowed' => 'Método Não Permitido',
    'error_default' => 'Ops, parece que algo deu errado',
    'language_not_supported' => 'Idioma não suportado',
];